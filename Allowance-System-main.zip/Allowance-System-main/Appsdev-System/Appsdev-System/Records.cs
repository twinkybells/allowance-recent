﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appsdev_System
{
    public partial class Records : Form
    {
        public string sql = "";
        public Records()
        {
            InitializeComponent();
        }

        private void clearfields()
        {
            txtIdNo.Text = "";
            txtFullName.Text = "";
            txtCourse.Text = "";
            txtYear.Text = "";
            txtCategory.Text = "";
            txtTotalAllowance.Text = "";
            cmbClaimStatus.Text = "";
            dpDateClaimed.Text = DateTime.Now.ToString();

            
        }

        private void Records_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'recordsDataSet2.records' table. You can move, or remove it, as needed.
            this.recordsTableAdapter.Fill(this.recordsDataSet2.records);
            txtWelcome.Text = LoginForm.sendtext;
            sql = "SELECT * from records";
            fill(sql, dgvRecords);

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            clearfields();
            Records_Load(sender, e);
        }

        public static void fill(string q, DataGridView dgv)
        {
            try
            {
                Connection.Connection.DBRec();
                DataTable dt = new DataTable();
                OleDbDataAdapter data = null;
                OleDbCommand command = new OleDbCommand(q, Connection.Connection.conn);
                data = new OleDbDataAdapter(command);
                data.Fill(dt);
                dgv.DataSource = dt;
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message, "Error FillDataGridView", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                //Check If One Or More Fields Are Empty
                if (txtIdNo.Text == String.Empty || txtFullName.Text == String.Empty || txtCourse.Text == String.Empty ||
                    txtYear.Text == String.Empty || txtCategory.Text == String.Empty || txtTotalAllowance.Text == String.Empty ||
                    cmbClaimStatus.Text == String.Empty)
                {
                    MessageBox.Show("Please make sure all fields are filled");
                }
                else
                {
                    OleDbCommand insertDataIntoMSAccessDataBaseOleDbCommand = new OleDbCommand(insertQuery, accessDatabaseConnection);
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@FullName", OleDbType.VarChar).Value = txtFullName.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@EmailAddress", OleDbType.VarChar).Value = txtEmail.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@PhoneNumberP", OleDbType.VarChar).Value = txtPhoneNumber.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@LanguageP", OleDbType.VarChar).Value = txtLanguage.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@CountryP", OleDbType.VarChar).Value = txtCountry.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@GenderP", OleDbType.VarChar).Value = txtGender.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@ImagePath", OleDbType.VarChar).Value = txtImagePath.Text;
                    insertDataIntoMSAccessDataBaseOleDbCommand.Parameters.AddWithValue("@ImageFile", OleDbType.Binary).Value = convertImageToByteArray(pictureBox1.Image);
                    //Opening Access Database Connection
                    accessDatabaseConnection.Open();
                    int insertDataToAccessDatabase = insertDataIntoMSAccessDataBaseOleDbCommand.ExecuteNonQuery();
                    //If data Has been inserted to the database output the following message
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.StackTrace);
                }
                finally
                {
                    //Finally Close MS Access Database Connection
                    if (accessDatabaseConnection != null)
                    {
                        accessDatabaseConnection.Close();
                    }
                }
                //Refreshing Datagridview after inserting new row
                populateDataGridView();
                //Clear Input Fields PictureBox And Textboxes
                clearfields();
        }
    }
}
